<!DOCTYPE blade.php>
<blade.php lang="eng">
    <head>
        <meta charset="UTF-8">
        <title>All Products-Almart</title>
        <link rel="stylesheet" href="style.css">
        <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@1,200;1,400;1,500;1,600;1,700&display=swap" rel="stylesheet">
<link rel ="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.3/css/fontawesome.min.css">
        </head>
        <body>
           


            
          <div class="container">
            <div class="navbar">
                <div class="logo">
                    <img src="images/logo.1.jpg" width="50px">
                </div>
                <nav>
                    
                    <ul>
                        <li><a href="../index.blade.php">Home</a></li>
                        <li><a href="../products.blade.php">Products</a></li>
                        <li><a href="../about.blade.php">About</a></li>
                        <li><a href="../contact.blade.php">Contact</a></li>
                        <li><a href="../account.blade.php">Account</a></li>
                    </ul>
                </nav>
                <a href="../cart.blade.php">
                <img src="images/cart.1.jpg" width="30px" height="30px">
                </a>
            </div>
           
          </div>

            

            <div class="small-container">
                <div class="row row-2">
                    <h2>The Roadstar</h2>
                </div>

                <div class="row">
                    <div class="col-4">
                        <img src="images/roadstarshirt1.jpeg"  >
                        <h4> <a href="roadstarshirt1.blade.php">ROADSTER 
                            Men Regular Fit Solid Casual Shirt</a></h4>
                        <div class="rating">
                            <i>&#9733; </i>
                            <i>&#9733;</i>
                            <i>&#9733;</i>
                            <i>&#9733;</i>
                            <i>&#9734;</i>
                           
                        </div>
                        <p>₹400.00</p>
                    </div>
                    <div class="col-4">
                        <img src="images/roadstarshirt2.jpeg"  >
                        <h4> <a href="roadstarshirt2.blade.php">Men Regular Fit Checkered Casual Shirt</a></h4>
                        <div class="rating">
                            <i>&#9733; </i>
                            <i>&#9733;</i>
                            <i>&#9733;</i>
                            <i>&#9733;</i>
                            <i>&#9733;</i>
                           
                        </div>
                        <p>₹500.00</p>
                    </div>
                    <div class="col-4">
                        <img src="images/roadstarshirt3.jpeg" >
                        <h4> <a href="roadstarshirt3.blade.php">ROADSTER 
                            Men Regular Fit Printed Mandarin Collar Casual Shirt</a></h4>
                        <div class="rating">
                            <i>&#9733; </i>
                            <i>&#9733;</i>
                            <i>&#9733;</i>
                            <i>&#9734;</i>
                            <i>&#9734;</i>
                            
                           
                        </div>
                        <p>₹450.00</p>
                    </div>
                    <div class="col-4">
                        <img src="images/roadstarphant1.jpeg" >
                        <h4> <a href="roadstarphant1.blade.php" >ROADSTER 
                            Regular Men Blue Jeans</a></h4>
                        <div class="rating">
                            <i>&#9733; </i>
                            <i>&#9733;</i>
                            <i>&#9733;</i>
                            <i>&#9733;</i>
                            <i>&#9734;</i>
                           
                        </div>
                        <p>₹520.00</p>
                    </div>
                </div>
                <!-----------latest products------->
                <div class="row">
                    <div class="col-4">
                        <img src="images/roadstar tshirt1.jpeg"  >
                        <h4> <a href="roadstar tshirt1.blade.php">ROADSTER 
                            Printed Men Round Neck Grey T-Shirt</a></h4>
                        <div class="rating">
                            <i>&#9733; </i>
                            <i>&#9733;</i>
                            <i>&#9733;</i>
                            <i>&#9733;</i>
                            <i>&#9734;</i>
                           
                        </div>
                        <p>₹200.00</p>
                    </div>
                    <div class="col-4">
                        <img src="images/roadstar ladiesphant1.jpeg"  >
                        <h4> <a href="roadstarladiesphant.blade.php">ROADSTER 
                            Super Skinny Women Blue Jeans</a></h4>
                        <div class="rating">
                            <i>&#9733; </i>
                            <i>&#9733;</i>
                            <i>&#9733;</i>
                            <i>&#9733;</i>
                            <i>&#9733;</i>
                           
                        </div>
                        <p>₹400.00</p>
                    </div>
                    <div class="col-4">
                        <img src="images/roadstar ladies t shirt1.jpeg">
                        <h4> <a href="roadstarladiestshirt1.blade.php">ROADSTER 
                            Printed Women Round Neck Black T-Shirt
                            </a></h4>
                        <div class="rating">
                            <i>&#9733; </i>
                            <i>&#9733;</i>
                            <i>&#9733;</i>
                            <i>&#9734;</i>
                            <i>&#9734;</i>
                            
                           
                        </div>
                        <p>₹450.00</p>
                    </div>
                    <div class="col-4">
                        <img src="images/roadstar ladies tshirt 2.jpeg">
                        <h4><a href="roadstar ladiestshirt2.blade.php">ROADSTER 
                            Casual Slit Sleeves Solid Women Pink Top</a></h4>
                        <div class="rating">
                            <i>&#9733; </i>
                            <i>&#9733;</i>
                            <i>&#9733;</i>
                            <i>&#9733;</i>
                            <i>&#9734;</i>
                           
                        </div>
                        <p>₹280.00</p>

                        
                       


                    </div>
                    
            </div> 
            </div>
           
           <!------------------fotter------>
           <div class="footer">
               <div class="container">
                   <div class="row">
                       <div class="footer-col-1">
                           <h3>Download our app</h3>
                           <p>Download app for android and ios mobile phone</p>
                           <div class="applogo">
                               <img src="images/playstore.png">
                               <img src="images/app store.png">
                           </div>
                       </div>
                       <div class="footer-col-2">
                        <img src="images/logo.1.jpg">
                        <p>Our purpose is to Sustainabley make the pleasure and Benfits of sports Accessible to the many</p>
                    </div>
                    
                      <div class="footer-col-4">
                      <h3>follow us</h3>
                      <ul>
                          <li>Facebook</li>
                          <li>Twitter</li>
                          <li>Instagram</li>
                          <li>Youtube</li>
                      </ul>
                  
                   </div>


                    
                   </div>
                   <hr>
                   <p class="copyright">Copyright 2021 -Almart  </p>
               </div>
           </div>
        </body>
    
    </blade.php>