<!DOCTYPE blade.php>
<blade.php lang="eng">
    <head>
        <meta charset="UTF-8">
        <title>All Products-Almart</title>
        <link rel="stylesheet" href="style.css">
        <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@1,200;1,400;1,500;1,600;1,700&display=swap" rel="stylesheet">
<link rel ="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.3/css/fontawesome.min.css">
        </head>
        <body>
           


            
          <div class="container">
            <div class="navbar">
                <div class="logo">
                    <img src="images/logo.1.jpg" width="50px">
                </div>
                <nav>
                    
                    <ul>
                        <li><a href="../index.blade.php">Home</a></li>
                        <li><a href="../products.blade.php">Products</a></li>
                        <li><a href="../about.blade.php">About</a></li>
                        <li><a href="../contact.blade.php">Contact</a></li>
                        <li><a href="../account.blade.php">Account</a></li>
                    </ul>
                </nav>
                <a href="../cart.blade.php">
                <img src="images/cart.1.jpg" width="30px" height="30px">
                </a>
            </div>
           
          </div>

            <!--------------single product page-->
            <div class="smallcontainer single-product" >
                <div class="row">
                    <div class="col-2">
                        <img src="images/ladies.jpeg" width="80%" height="50%" id="productimg" >
                        <div class="small-img-row">
                            <div class="small-img-col">
                                <img src="images/ladies2.jpeg" width="80%" height="50%" class="small-img">
                            </div>
                            <div class="small-img-col">
                                <img src="images/ladies3.jpeg" width="80" height="50%" class="small-img">
                            </div>
                            <div class="small-img-col">
                                <img src="images/ladies4.jpeg" width="80" height="50%" class="small-img">
                            </div>
                            <div class="small-img-col">
                                <img src="images/ladies5.jpeg" width="80%" height="50%" class="small-img">
                            </div>
                        </div>

                    </div>
                    <div class="col-2">
                        <p>Home /  Ladies Ware</p>
                        <h1>Crepe Printed Salwar Suit Material</h1>
                        <h4>₹250.00</h4>
                        <select>
                            <option>Select size</option>
                            <option>l</option>
                            <option>m</option>
                            <option>s</option>
                        </select>
                        <input type="number" value="1">
                        <a href="" class="btn">Add to cart</a>
                        <h3>Product details</h3>
                        <p>Crepe Printed Salwar Suit Material</p>
                    </div>
                </div>
            </div>
            <!---------title------>
            <div class="small-container">
                <div class="row row-2">
                    <h2>Related products</h2>
                    <p>view more</p>
                </div>
            </div>
<!---------------------products-->
            <div class="small-container">
                <div class="row">
                    <div class="col-4">
                        <img src="images/Graphic Print Men Round Neck Black T-Shirt 1.jpeg"  width="250px" height="250px">
                        <h4> <a href="blackshirtproductdetails.blade.php">Black Printed Tshirt</a></h4>
                        <div class="rating">
                            <i>&#9733; </i>
                            <i>&#9733;</i>
                            <i>&#9733;</i>
                            <i>&#9733;</i>
                            <i>&#9734;</i>
                           
                        </div>
                        <p>₹300.00</p>
                    </div>
                    <div class="col-4">
                        <img src="images/shoe1.1.jpeg"  >
                        <h4> <a href="whiteshoes.blade.php">White shoes</a></h4>
                        <div class="rating">
                            <i>&#9733; </i>
                            <i>&#9733;</i>
                            <i>&#9733;</i>
                            <i>&#9733;</i>
                            <i>&#9733;</i>
                           
                        </div>
                        <p>₹500.00</p>
                    </div>
                    <div class="col-4">
                        <img src="images/track phant 1.jpeg" width="30px" height="300px">
                        <h4> <a href="trackphant.blade.php">Black track phant by qurty</a></h4>
                        <div class="rating">
                            <i>&#9733; </i>
                            <i>&#9733;</i>
                            <i>&#9733;</i>
                            <i>&#9734;</i>
                            <i>&#9734;</i>
                            
                           
                        </div>
                        <p>₹250.00</p>
                    </div>
                    <div class="col-4">
                        <img src="images/shirt 7.1.jpeg"  width="250px" height="250px">
                        <h4> <a href="greyandblackforwomen.blade.php" >Grey&Black T shirt for women</a></h4>
                        <div class="rating">
                            <i>&#9733; </i>
                            <i>&#9733;</i>
                            <i>&#9733;</i>
                            <i>&#9733;</i>
                            <i>&#9734;</i>
                           
                        </div>
                        <p>₹320.00</p>
                    </div>
                </div>
                <!-----------latest products------->
               >
                    
            </div>   
            
           
           <!------------------fotter------>
           <div class="footer">
               <div class="container">
                   <div class="row">
                       <div class="footer-col-1">
                           <h3>Download our app</h3>
                           <p>Download app for android and ios mobile phone</p>
                           <div class="applogo">
                               <img src="images/playstore.png">
                               <img src="images/app store.png">
                           </div>
                       </div>
                       <div class="footer-col-2">
                        <img src="images/logo.1.jpg">
                        <p>Our purpose is to Sustainabley make the pleasure and Benfits of sports Accessible to the many</p>
                    </div>
                    <div class="footer-col-3">
                        <h3>Useful links</h3>
                        <ul>
                            <li>Coupnes</li>
                            <li>Blog post</li>
                            <li>Return Policy</li>
                            <li>join Affiliate</li>
                        </ul>
                        
                      </div>
                      <div class="footer-col-4">
                      <h3>follow us</h3>
                      <ul>
                          <li>Facebook</li>
                          <li>Twitter</li>
                          <li>Instagram</li>
                          <li>Youtube</li>
                      </ul>
                  
                   </div>


                    
                   </div>
                   <hr>
                   <p class="copyright">Copyright 2021 -Almart  </p>
               </div>
           </div>

           <!---------js for product gallary--------->
           <script>
               var productimg =document.getElementById("productimg");
               var smallimg =document.getElementsByClassName("small-img");
               smallimg[0].onclick =function(){
                   productimg.src=smallimg[0].src;
               }
               smallimg[1].onclick =function(){
                   productimg.src=smallimg[1].src;
               }
               smallimg[2].onclick =function(){
                   productimg.src=smallimg[2].src;
               }
               smallimg[3].onclick =function(){
                   productimg.src=smallimg[3].src;
               }
           </script>
        </body>
    
    </blade.php>