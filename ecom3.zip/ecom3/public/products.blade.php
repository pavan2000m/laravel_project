<!DOCTYPE blade.php>
<blade.php lang="eng">
    <head>
        <meta charset="UTF-8">
        <title>All Products-Almart</title>
        <link rel="stylesheet" href="style.css">
        <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@1,200;1,400;1,500;1,600;1,700&display=swap" rel="stylesheet">
<link rel ="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.3/css/fontawesome.min.css">
        </head>
        <body>
           


            
          <div class="container">
            <div class="navbar">
                <div class="logo">
                    <img src="images/logo.1.jpg" width="50px">
                </div>
                <nav>
                    
                    <ul>
                        <li><a href="index.blade.php">Home</a></li>
                        <li><a href="products.blade.php">Products</a></li>
                        <li><a href="about.blade.php">About</a></li>
                        <li><a href="contact.blade.php">Contact</a></li>
                        <li><a href="account.blade.php">Account</a></li>
                    </ul>
                </nav>
                <a href="cart.blade.php">
                <img src="images/cart.1.jpg" width="30px" height="30px">
                </a>
            </div>
           
          </div>

            

            <div class="small-container">
                <div class="row row-2">
                    <h2>All products</h2>
                    <select>
                        <option>Deafult shorting</option>
                        <option>short by price</option>
                        <option>short by popularity</option>
                        <option>short by rating</option>
                        <option>short by sale</option>
                    </select>
                </div>

                <div class="row">
                    <div class="col-4">
                        <img src="images/Graphic Print Men Round Neck Black T-Shirt 1.jpeg"  width="250px" height="250px">
                        <h4> <a href="prodata/blackshirtproductdetails.blade.php">Black Printed Tshirt</a></h4>
                        <div class="rating">
                            <i>&#9733; </i>
                            <i>&#9733;</i>
                            <i>&#9733;</i>
                            <i>&#9733;</i>
                            <i>&#9734;</i>
                           
                        </div>
                        <p>₹300.00</p>
                    </div>
                    <div class="col-4">
                        <img src="images/shoe1.1.jpeg"  >
                        <h4> <a href="prodata/whiteshoes.blade.php">white shoes by jxs</a></h4>
                        <div class="rating">
                            <i>&#9733; </i>
                            <i>&#9733;</i>
                            <i>&#9733;</i>
                            <i>&#9733;</i>
                            <i>&#9733;</i>
                           
                        </div>
                        <p>₹500.00</p>
                    </div>
                    <div class="col-4">
                        <img src="images/track1.jpeg" width="30px" height="300px">
                        <h4> <a href="prodata/trackphant.blade.php">Black track phant by qurty</a></h4>
                        <div class="rating">
                            <i>&#9733; </i>
                            <i>&#9733;</i>
                            <i>&#9733;</i>
                            <i>&#9734;</i>
                            <i>&#9734;</i>
                            
                           
                        </div>
                        <p>₹250.00</p>
                    </div>
                    <div class="col-4">
                        <img src="images/shirt 7.1.jpeg"  width="250px" height="250px">
                        <h4> <a href="prodata/greyandblackforwomen.blade.php" >Grey&Black T shirt for women</a></h4>
                        <div class="rating">
                            <i>&#9733; </i>
                            <i>&#9733;</i>
                            <i>&#9733;</i>
                            <i>&#9733;</i>
                            <i>&#9734;</i>
                           
                        </div>
                        <p>₹320.00</p>
                    </div>
                </div>
                <!-----------latest products------->
                <div class="row">
                    <div class="col-4">
                        <img src="images/shirt 3.jpeg"  >
                        <h4> <a href="productdetails.blade.php">Red Printed Tshirt</a></h4>
                        <div class="rating">
                            <i>&#9733; </i>
                            <i>&#9733;</i>
                            <i>&#9733;</i>
                            <i>&#9733;</i>
                            <i>&#9734;</i>
                           
                        </div>
                        <p>₹300.00</p>
                    </div>
                    <div class="col-4">
                        <img src="images/fitband.jpeg"  >
                        <h4> <a href="prodata/fitband.blade.php">Fitband by nova</a></h4>
                        <div class="rating">
                            <i>&#9733; </i>
                            <i>&#9733;</i>
                            <i>&#9733;</i>
                            <i>&#9733;</i>
                            <i>&#9733;</i>
                           
                        </div>
                        <p>₹500.00</p>
                    </div>
                    <div class="col-4">
                        <img src="images/shirt 4.1.jpeg">
                        <h4> <a href="prodata/multicolorshirt.blade.php">multi color t shirt for men by jxs</a></h4>
                        <div class="rating">
                            <i>&#9733; </i>
                            <i>&#9733;</i>
                            <i>&#9733;</i>
                            <i>&#9734;</i>
                            <i>&#9734;</i>
                            
                           
                        </div>
                        <p>₹150.00</p>
                    </div>
                    <div class="col-4">
                        <img src="images/socks.jpeg">
                        <h4><a href="prodata/socks.blade.php"> Men & Women Low Cut, Ankle Length  (Pack of 3)</a></h4>
                        <div class="rating">
                            <i>&#9733; </i>
                            <i>&#9733;</i>
                            <i>&#9733;</i>
                            <i>&#9733;</i>
                            <i>&#9734;</i>
                           
                        </div>
                        <p>₹80.00</p>

                        
                       


                    </div>
                    <div class="row">
                        <div class="col-4">
                            <img src="images/kids.jpeg"  >
                            <h4><a href=prodata/kids1.blade.php>kids Festive & Party Dhoti & Kurta Set  (White Pack of 1)</a></h4>
                            <div class="rating">
                                <i>&#9733; </i>
                                <i>&#9733;</i>
                                <i>&#9733;</i>
                                <i>&#9733;</i>
                                <i>&#9734;</i>
                               
                            </div>
                            <p>₹300.00</p>
                        </div>
                        <div class="col-4">
                            <img src="images/formal shirt.jpeg"  >
                            <h4><a href=prodata/formalshirt.blade.php>Men Slim Fit Solid Slim Collar Formal Shirt</a></h4>
                            <div class="rating">
                                <i>&#9733; </i>
                                <i>&#9733;</i>
                                <i>&#9733;</i>
                                <i>&#9733;</i>
                                <i>&#9733;</i>
                               
                            </div>
                            <p>₹500.00</p>
                        </div>
                        <div class="col-4">
                            <img src="images/ladies.jpeg">
                            <h4><a href=prodata/ladiesdree.blade.php>Crepe Printed Salwar Suit Material  (Unstitched)</a></h4>
                            <div class="rating">
                                <i>&#9733; </i>
                                <i>&#9733;</i>
                                <i>&#9733;</i>
                                <i>&#9734;</i>
                                <i>&#9734;</i>
                                
                               
                            </div>
                            <p>₹250.00</p>
                        </div>
                        <div class="col-4">
                            <img src="images/slippers.jpeg" >
                            <h4><a href=prodata/slippers.blade.php>Bride Slippers </a></h4>
                            <div class="rating">
                                <i>&#9733; </i>
                                <i>&#9733;</i>
                                <i>&#9733;</i>
                                <i>&#9733;</i>
                                <i>&#9734;</i>
                               
                            </div>
                            <p>₹320.00</p>
    
                    
                </div>
            </div>
             <div class="page-btn">
                 <span>1</span>
                 <span>2</span>
                 <span>3</span>
                 <span>4</span>
                 <span>&#8594;</span>
             </div>
                
                
            </div>
           
           <!------------------fotter------>
           <div class="footer">
               <div class="container">
                   <div class="row">
                       <div class="footer-col-1">
                           <h3>Download our app</h3>
                           <p>Download app for android and ios mobile phone</p>
                           <div class="applogo">
                               <img src="images/playstore.png">
                               <img src="images/app store.png">
                           </div>
                       </div>
                       <div class="footer-col-2">
                        <img src="images/logo.1.jpg">
                        <p>Our purpose is to Sustainabley make the pleasure and Benfits of sports Accessible to the many</p>
                    </div>
                    
                      <div class="footer-col-4">
                      <h3>follow us</h3>
                      <ul>
                          <li>Facebook</li>
                          <li>Twitter</li>
                          <li>Instagram</li>
                          <li>Youtube</li>
                      </ul>
                  
                   </div>


                    
                   </div>
                   <hr>
                   <p class="copyright">Copyright 2021 -Almart  </p>
               </div>
           </div>
        </body>
    
    </blade.php>