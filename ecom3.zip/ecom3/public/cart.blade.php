<!DOCTYPE blade.php>
<blade.php lang="eng">
    <head>
        <meta charset="UTF-8">
        <title>All Products-Almart</title>
        <link rel="stylesheet" href="style.css">
        <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@1,200;1,400;1,500;1,600;1,700&display=swap" rel="stylesheet">
<link rel ="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.3/css/fontawesome.min.css">
        </head>
        <body>
           


            
          <div class="container">
            <div class="navbar">
                <div class="logo">
                    <img src="images/logo.1.jpg" width="50px">
                </div>
                <nav>
                    
                    <ul>
                        <li><a href="index.blade.php">Home</a></li>
                        <li><a href="products.blade.php">Products</a></li>
                        <li><a href="about.blade.php">About</a></li>
                        <li><a href="contact.blade.php">Contact</a></li>
                        <li><a href="account.blade.php">Account</a></li>
                    </ul>
                </nav>
                <a href="cart.blade.php">
                <img src="images/cart.1.jpg" width="30px" height="30px">
                </a>
            </div>
           
          </div>

         <!------------------------cart item details-->

         <div class="small-container cart-page">
             <table>
                 <tr>
                     <th>product</th>
                     <th>Quantity</th>
                     <th>Subtotal</th>
                 </tr>
                 <tr>
                     <td>
                         <div class="cart-info">
                             <img src="images/Graphic Print Men Round Neck Black T-Shirt 1.jpeg" >
                             <div>
                                 <p>black printed t shirt</p>
                                 <small>Price:₹300.00</small><br>
                                 <a href="">Remove</a>
                             </div>
                         </div>
                     </td>
                     <td><input type="number" value="1"></td>
                     <td>₹300.00</td>
                 </tr>
                 <tr>
                    <td>
                        <div class="cart-info">
                            <img src="images/socks.jpeg" >
                            <div>
                                <p>socks</p>
                                <small>Price:₹100.00</small><br>
                                <a href="">Remove</a>
                            </div>
                        </div>
                    </td>
                    <td><input type="number" value="1"></td>
                    <td>₹100.00</td>
                </tr>
                <tr>
                    <td>
                        <div class="cart-info">
                            <img src="images/shirt 2.jpeg" >
                            <div>
                                <p>black &grey printed t shirt</p>
                                <small>Price:₹300.00</small><br>
                                <a href="">Remove</a>
                            </div>
                        </div>
                    </td>
                    <td><input type="number" value="1"></td>
                    <td>₹300.00</td>
                </tr>


                <div class="total-price">
                    <table>
                        <tr>
                            <td>Subtotal</td>
                            <td>₹700.00</td>
                        </tr>
                        <tr>
                            <td>Tax</td>
                            <td>₹35.00</td>
                        </tr>
                        <tr>
                            <td>Total</td>
                            <td>₹735.00</td>
                        </tr>
                    </table>
                </div>
             </table>
         </div>
            
           
           <!------------------fotter------>
           <div class="footer">
               <div class="container">
                   <div class="row">
                       <div class="footer-col-1">
                           <h3>Download our app</h3>
                           <p>Download app for android and ios mobile phone</p>
                           <div class="applogo">
                               <img src="images/playstore.png">
                               <img src="images/app store.png">
                           </div>
                       </div>
                       <div class="footer-col-2">
                        <img src="images/logo.1.jpg">
                        <p>Our purpose is to Sustainabley make the pleasure and Benfits of sports Accessible to the many</p>
                    </div>
                    <div class="footer-col-3">
                        <h3>Useful links</h3>
                        <ul>
                            <li>Coupnes</li>
                            <li>Blog post</li>
                            <li>Return Policy</li>
                            <li>join Affiliate</li>
                        </ul>
                        
                      </div>
                      <div class="footer-col-4">
                      <h3>follow us</h3>
                      <ul>
                          <li>Facebook</li>
                          <li>Twitter</li>
                          <li>Instagram</li>
                          <li>Youtube</li>
                      </ul>
                  
                   </div>


                    
                   </div>
                   <hr>
                   <p class="copyright">Copyright 2021 -Almart  </p>
               </div>
           </div>
        </body>
    
    </blade.php>