<!DOCTYPE html>
<html lang="eng">
    <head>
        <meta charset="UTF-8">
        <title>Almart</title>
        <link rel="stylesheet" href="style.css">
        <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@1,200;1,400;1,500;1,600;1,700&display=swap" rel="stylesheet">
<link rel ="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@5.15.3/css/fontawesome.min.css">
        </head>
        <body>
            <div class="header">


            
          <div class="container">
            <div class="navbar">
                <div class="logo">
                    <img src="images/logo.1.jpg" width="50px">
                    
                </div>
                <nav>
                    
                    <ul>
                        <li><a href="index.blade.php">Home</a></li>
                        <li><a href="products.blade.php">Products</a></li>
                        <li><a href="about.blade.php">About</a></li>
                        <li><a href="contact.blade.php">Contact</a></li>
                        <li><a href="account.blade.php">Account</a></li>
                    </ul>
                </nav>
                <a href="cart.html">
                <img src="images/cart.1.jpg" width="30px" height="30px">
                </a>
            </div>
            <div class="row">
                <div class="col-2">
                    <h1>Give your Present<br> A New Style!</h1>
                    <p>Style is a way to say who you are without having to speak</p>
                    <a href="products" class="btn">Explore Now &#8594;</a>

                </div>
                <div class="col-2">
                    <img src="images/fashion.2.jpg" >

                </div>
            </div>
          </div>
        </div>


        <!---------------featured categories-->
        <div class="categories">

            <div class="small-container">
                <div class="row">
                    <div class="col-3">
                        <a href="prodata/theroadstar.html">
                        <img src="images/catgory 1">
                        </a>
                    </div>
                    <div class="col-3">
                        <a href="prodata/theroadstar.html"></ahref>
                        <img src="images/catgory 2.webp">
                        </a>
                    </div>
                    <div class="col-3">
                        <a href="prodata/theroadstar.html">
                        <img src="images/catgory 3.webp">
                        </a>
                    </div>
                    
                </div>
            </div>

            </div>

            <!---------------featured products-------------->

            <div class="small-container">

                <h2 class="title">Featured Products</h2>
                <div class="row">
                    <div class="col-4">
                        <img src="images/Graphic Print Men Round Neck Black T-Shirt 1.jpeg"  width="250px" height="250px">
                        <h4> <a href="prodata/blackshirtproductdetails.html">Black Printed Tshirt</a></h4>
                        <div class="rating">
                            <i>&#9733; </i>
                            <i>&#9733;</i>
                            <i>&#9733;</i>
                            <i>&#9733;</i>
                            <i>&#9734;</i>
                           
                        </div>
                        <p>₹300.00</p>
                    </div>
                    <div class="col-4">
                        <img src="images/shoe1.1.jpeg"  >
                        <h4> <a href="prodata/whiteshoes.html">white shoes by jxs</a></h4>
                        <div class="rating">
                            <i>&#9733; </i>
                            <i>&#9733;</i>
                            <i>&#9733;</i>
                            <i>&#9733;</i>
                            <i>&#9733;</i>
                           
                        </div>
                        <p>₹500.00</p>
                    </div>
                    <div class="col-4">
                        <img src="images/track phant.jpeg" >
                        <h4> <a href="prodata/trackphant.html">Black track phant by qurty</a></h4>
                        <div class="rating">
                            <i>&#9733; </i>
                            <i>&#9733;</i>
                            <i>&#9733;</i>
                            <i>&#9734;</i>
                            <i>&#9734;</i>
                            
                           
                        </div>
                        <p>₹250.00</p>
                    </div>
                    <div class="col-4">
                        <img src="images/shirt 7.1.jpeg"  >
                        <h4> <a href="prodata/greyandblackforwomen.html" >Grey&Black T shirt for women</a></h4>
                        <div class="rating">
                            <i>&#9733; </i>
                            <i>&#9733;</i>
                            <i>&#9733;</i>
                            <i>&#9733;</i>
                            <i>&#9734;</i>
                           
                        </div>
                        <p>₹320.00</p>
                    </div>
                </div>
                <!-----------latest products------->
                <h2 class="title">Latest Products</h2>
                <div class="row">
                    <div class="col-4">
                        <img src="images/shirt 3.jpeg"  >
                        <h4> <a href="productdetails.html">Red Printed Tshirt</a></h4>
                        <div class="rating">
                            <i>&#9733; </i>
                            <i>&#9733;</i>
                            <i>&#9733;</i>
                            <i>&#9733;</i>
                            <i>&#9734;</i>
                           
                        </div>
                        <p>₹300.00</p>
                    </div>
                    <div class="col-4">
                        <img src="images/fitband.jpeg"  >
                        <h4> <a href="prodata/fitband.html">Fitband by nova</a></h4>
                        <div class="rating">
                            <i>&#9733; </i>
                            <i>&#9733;</i>
                            <i>&#9733;</i>
                            <i>&#9733;</i>
                            <i>&#9733;</i>
                           
                        </div>
                        <p>₹500.00</p>
                    </div>
                    <div class="col-4">
                        <img src="images/shirt 4.1.jpeg">
                        <h4> <a href="prodata/multicolorshirt.html">multi color t shirt for men by jxs</a></h4>
                        <div class="rating">
                            <i>&#9733; </i>
                            <i>&#9733;</i>
                            <i>&#9733;</i>
                            <i>&#9734;</i>
                            <i>&#9734;</i>
                            
                           
                        </div>
                        <p>₹150.00</p>
                    </div>
                    <div class="col-4">
                        <img src="images/socks.jpeg">
                        <h4><a href="prodata/socks.html"> Men & Women Low Cut, Ankle Length  (Pack of 3)</a></h4>
                        <div class="rating">
                            <i>&#9733; </i>
                            <i>&#9733;</i>
                            <i>&#9733;</i>
                            <i>&#9733;</i>
                            <i>&#9734;</i>
                           
                        </div>
                        <p>₹80.00</p>

                        
                       


                    </div>
                    <div class="row">
                        <div class="col-4">
                            <img src="images/kids.jpeg"  >
                            <h4><a href=prodata/kids1.html>kids Festive & Party Dhoti & Kurta Set  (White Pack of 1)</a></h4>
                            <div class="rating">
                                <i>&#9733; </i>
                                <i>&#9733;</i>
                                <i>&#9733;</i>
                                <i>&#9733;</i>
                                <i>&#9734;</i>
                               
                            </div>
                            <p>₹300.00</p>
                        </div>
                        <div class="col-4">
                            <img src="images/formal shirt.jpeg"  >
                            <h4><a href=prodata/formalshirt.html>Men Slim Fit Solid Slim Collar Formal Shirt</a></h4>
                            <div class="rating">
                                <i>&#9733; </i>
                                <i>&#9733;</i>
                                <i>&#9733;</i>
                                <i>&#9733;</i>
                                <i>&#9733;</i>
                               
                            </div>
                            <p>₹500.00</p>
                        </div>
                        <div class="col-4">
                            <img src="images/ladies.jpeg">
                            <h4><a href=prodata/ladiesdree.html>Crepe Printed Salwar Suit Material  (Unstitched)</a></h4>
                            <div class="rating">
                                <i>&#9733; </i>
                                <i>&#9733;</i>
                                <i>&#9733;</i>
                                <i>&#9734;</i>
                                <i>&#9734;</i>
                                
                               
                            </div>
                            <p>₹250.00</p>
                        </div>
                        <div class="col-4">
                            <img src="images/slippers.jpeg" >
                            <h4><a href=prodata/slippers.html>Bride Slippers</a></h4>
                            <div class="rating">
                                <i>&#9733; </i>
                                <i>&#9733;</i>
                                <i>&#9733;</i>
                                <i>&#9733;</i>
                                <i>&#9734;</i>
                               
                            </div>
                            <p>₹200.00</p>
    
                    
                </div>
                
            </div>
           

           <!-------------------offer---->
           <div class="offer">
           <div class="small-container">
               <div class="row">
                   <div class="col-2">
                       <img src="images/apple.jpg" class="offer-img">
                   </div>
                   <div class="col-2">
                       <p>Exclusively Avalible in Almart</p>
                       <h1>Apple i Watch</h1>
                       <small>APPLE watch series 3 Gps -42mm space grey case with red sportband
                            </small><br>

                       <a href="prodata/iwatch.html" class="btn">Buy Now &#8594;</a>

                   </div>
               </div>
           </div> 
           </div>



           <!---------------testimonial---------->
           <div class="testimonial">
               <div class="small-container">
                   <div class="row">
                       <div class="col-3">
                           <i>&#8220;</i>
                           <p>this is some text</p>
                           <div class="rating">
                            <i>&#9733; </i>
                            <i>&#9733;</i>
                            <i>&#9733;</i>
                            <i>&#9733;</i>
                            <i>&#9734;</i>
                           
                        </div>
                        <img src="images/johnsena.jpg">
                        <h3>jhon</h3>
                    
                       </div>
                       <div class="col-3">
                        <i>&#8221;</i>
                        <p>this is some text</p>
                        <div class="rating">
                         <i>&#9733; </i>
                         <i>&#9733;</i>
                         <i>&#9733;</i>
                         <i>&#9733;</i>
                         <i>&#9734;</i>
                        
                     </div>
                     <img src="images/kathrene.jpg">
                     <h3>kathrene</h3>
                 
                    </div>
                    <div class="col-3">
                        <i>&#8221;</i>
                        <p>this is some text</p>
                        <div class="rating">
                         <i>&#9733; </i>
                         <i>&#9733;</i>
                         <i>&#9733;</i>
                         <i>&#9733;</i>
                         <i>&#9734;</i>
                        
                     </div>
                     <img src="images/perry.jpg">
                     <h3>Perry</h3>
                 
                    </div>
                       

                   </div>
                   
                   
               </div>
           </div>


           <!-------------brands------>
           <div class="brands">
               <div class="small-container">
                   <div class="row">
                       <div class="col-5">
                           <img src="images/ceat logo.jpg">
                       </div>
                       <div class="col-5">
                        <img src="images/godrej logo.png">
                    </div>
                    <div class="col-5">
                        <img src="images/paytm logo.png">
                    </div>
                    <div class="col-5">
                        <img src="images/oppo logo.png">
                    </div>
                    <div class="col-5">
                        <img src="images/voltas logo.png">
                    </div>
                   </div>
               </div>
           </div>
          <!------------------fotter------>
          <div class="footer">
            <div class="container">
                <div class="row">
                    <div class="footer-col-1">
                        <h3>Download our app</h3>
                        <p>Download app for android and ios mobile phone</p>
                        <div class="applogo">
                            <img src="images/playstore.png">
                            <img src="images/app store.png">
                        </div>
                    </div>
                    <div class="footer-col-2">
                     <img src="images/logo.1.jpg">
                     <p>Our purpose is to Sustainabley make the pleasure and Benfits of sports Accessible to the many</p>
                 </div>
                 
                   <div class="footer-col-4">
                   <h3>follow us</h3>
                   <ul>
                       <li>Facebook</li>
                       <li>Twitter</li>
                       <li>Instagram</li>
                       <li>Youtube</li>
                   </ul>
               
                </div>


                 
                </div>
                <hr>
                <p class="copyright">Copyright 2021 -Almart  </p>
            </div>
        </div>
     </body>
 
 </html>